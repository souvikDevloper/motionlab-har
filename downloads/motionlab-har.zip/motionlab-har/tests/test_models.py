import numpy as np
import pytest
import torch

from har.constants import CHANNELS, DEEP_MODELS
from har.data import SignalScaler
from har.inference import Predictor
from har.models import load_model, make_model

torch.set_num_threads(2)


@pytest.mark.parametrize("name", DEEP_MODELS)
def test_models_support_batch_one_and_training_gradients(name):
    model = make_model(name)
    inputs = torch.randn(2, 128, 6)
    output = model(inputs)
    assert output.shape == (2, 6)
    torch.nn.functional.cross_entropy(output, torch.tensor([0, 1])).backward()
    assert all(parameter.grad is not None and torch.isfinite(parameter.grad).all()
               for parameter in model.parameters())
    model.eval()
    assert model(inputs[:1]).shape == (1, 6)


def test_saved_weights_round_trip_and_predictor_validation(tmp_path):
    model = make_model("cnn_lstm").eval()
    torch.save({"format_version": 1, "model_key": "cnn_lstm", "state_dict": model.state_dict(),
                "channels": list(CHANNELS), "window": 128}, tmp_path / "cnn_lstm.pt")
    scaler = SignalScaler(np.zeros(6, dtype=np.float32), np.ones(6, dtype=np.float32))
    scaler.save(tmp_path / "signal_scaler.npz")
    loaded, _ = load_model(tmp_path / "cnn_lstm.pt")
    signals = np.random.default_rng(42).normal(size=(2, 128, 6)).astype(np.float32)
    np.testing.assert_allclose(model(torch.from_numpy(signals)).detach().numpy(),
                               loaded(torch.from_numpy(signals)).detach().numpy())
    predictor = Predictor.load(tmp_path, "cnn_lstm")
    probabilities = predictor.predict(signals)
    np.testing.assert_allclose(probabilities.sum(1), np.ones(2), atol=1e-6)
    for invalid in [signals[0], signals[:, :, :3], signals[:0], signals * np.nan]:
        with pytest.raises(ValueError):
            predictor.predict(invalid)

