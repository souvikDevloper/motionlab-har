import io

import numpy as np
import pandas as pd
import pytest

from har.augment import corrupt, rotate, training_augmentation
from har.constants import CHANNELS
from har.data import SignalScaler, participant_split
from har.inference import make_windows, prediction_frame, read_sensor_csv


def test_participants_stay_together_and_all_labels_survive():
    subjects = np.repeat(np.arange(1, 22), 12)
    labels = np.tile(np.arange(6), 42)
    fit, val = participant_split(subjects, labels, seed=42)
    assert not set(subjects[fit]) & set(subjects[val])
    assert len(set(subjects[fit])) == 16
    assert len(set(subjects[val])) == 5
    assert sorted(np.concatenate([fit, val])) == list(range(len(subjects)))


def test_scaler_uses_only_fit_statistics_and_handles_constant_channels(tmp_path):
    fit = np.zeros((2, 128, 6), dtype=np.float32)
    fit[1] = np.arange(6)
    scaler = SignalScaler.fit(fit)
    np.testing.assert_allclose(scaler.mean, np.arange(6) / 2)
    assert np.isfinite(scaler.transform(fit)).all()
    unseen = np.full((1, 128, 6), 100, dtype=np.float32)
    before = scaler.mean.copy()
    scaler.transform(unseen)
    np.testing.assert_array_equal(before, scaler.mean)
    scaler.save(tmp_path / "scaler.npz")
    restored = SignalScaler.load(tmp_path / "scaler.npz")
    np.testing.assert_array_equal(scaler.transform(fit), restored.transform(fit))


def test_rotation_preserves_norm_and_applies_same_rotation_to_both_sensors():
    values = np.random.default_rng(3).normal(size=(8, 128, 3)).astype(np.float32)
    signals = np.concatenate([values, values * 2], axis=-1)
    rotated = rotate(signals, 30, np.random.default_rng(42))
    np.testing.assert_allclose(np.linalg.norm(signals[:, :, :3], axis=-1),
                               np.linalg.norm(rotated[:, :, :3], axis=-1), rtol=1e-5)
    np.testing.assert_allclose(rotated[:, :, 3:], 2 * rotated[:, :, :3], rtol=1e-5)
    assert not np.array_equal(signals, rotated)


@pytest.mark.parametrize("condition", ["clean", "noise_0.1", "noise_0.3", "noise_0.5", "rotation_15", "rotation_30", "missing_10"])
def test_corruptions_are_reproducible_finite_and_do_not_modify_input(condition):
    signals = np.random.default_rng(1).normal(size=(3, 128, 6)).astype(np.float32)
    original = signals.copy()
    first = corrupt(signals, condition, np.ones(6), np.zeros(6), seed=15)
    second = corrupt(signals, condition, np.ones(6), np.zeros(6), seed=15)
    np.testing.assert_array_equal(first, second)
    np.testing.assert_array_equal(signals, original)
    assert first.shape == signals.shape and np.isfinite(first).all()


def test_missing_block_replaces_exactly_13_consecutive_readings():
    signals = np.ones((4, 128, 6), dtype=np.float32)
    result = corrupt(signals, "missing_10", np.ones(6), np.zeros(6))
    for window in result:
        indices = np.flatnonzero(np.all(window == 0, axis=1))
        assert len(indices) == 13
        np.testing.assert_array_equal(np.diff(indices), np.ones(12))


def test_noise_is_measured_in_training_standard_deviations():
    signals = np.zeros((100, 128, 6), dtype=np.float32)
    scale = np.arange(1, 7, dtype=np.float32)
    result = corrupt(signals, "noise_0.3", scale, np.zeros(6))
    np.testing.assert_allclose(result.std(axis=(0, 1)), scale * 0.3, rtol=0.04)


def test_training_augmentation_keeps_clean_anchors_and_does_not_mutate():
    signals = np.ones((100, 128, 6), dtype=np.float32)
    result = training_augmentation(signals, np.ones(6), np.zeros(6), np.random.default_rng(42))
    clean_count = np.all(result == signals, axis=(1, 2)).sum()
    assert 20 < clean_count < 80
    assert np.all(signals == 1)


def csv_frame(rows=256):
    frame = pd.DataFrame(np.ones((rows, 6)), columns=CHANNELS)
    frame.insert(0, "timestamp_s", np.arange(rows) / 50)
    return frame


def test_csv_windowing_is_exact_and_preserves_channel_order():
    source = csv_frame()
    source["gyro_z"] = np.arange(len(source))
    frame = read_sensor_csv(io.StringIO(source.to_csv(index=False)))
    windows, starts = make_windows(frame[list(CHANNELS)].to_numpy())
    assert windows.shape == (3, 128, 6)
    np.testing.assert_array_equal(starts, [0, 64, 128])
    np.testing.assert_array_equal(windows[1, :, 5], np.arange(64, 192))


@pytest.mark.parametrize("problem", ["short", "missing_channel", "nan", "inf", "text", "irregular", "reverse_time"])
def test_invalid_csv_is_rejected_with_actionable_error(problem):
    frame = csv_frame(127 if problem == "short" else 128)
    if problem == "missing_channel":
        frame = frame.drop(columns=["acc_x"])
    elif problem in {"nan", "inf", "text"}:
        frame = frame.astype(object)
        frame.loc[10, "gyro_y"] = {"nan": np.nan, "inf": np.inf, "text": "bad"}[problem]
    elif problem == "irregular":
        frame.loc[10, "timestamp_s"] += 0.01
    elif problem == "reverse_time":
        frame["timestamp_s"] = frame["timestamp_s"][::-1].to_numpy()
    with pytest.raises(ValueError):
        read_sensor_csv(io.StringIO(frame.to_csv(index=False)))


def test_csv_without_timestamps_is_supported_with_explicit_rate_contract():
    frame = read_sensor_csv(io.StringIO(csv_frame(128).drop(columns=["timestamp_s"]).to_csv(index=False)))
    windows, _ = make_windows(frame.to_numpy())
    assert windows.shape == (1, 128, 6)


def test_prediction_export_has_correct_intervals_and_label_mapping():
    probabilities = np.eye(6, dtype=np.float32)[[0, 5]]
    frame = prediction_frame(probabilities, np.array([0, 64]))
    assert list(frame["activity"]) == ["Walking", "Lying down"]
    np.testing.assert_allclose(frame["start_s"], [0, 1.28])
    np.testing.assert_allclose(frame["end_s"], [2.56, 3.84])

