from pathlib import Path

import pytest

from har.constants import ROOT


@pytest.mark.skipif(not (ROOT / "results" / "experiment.json").exists(), reason="Train the models before testing the dashboard.")
def test_dashboard_models_corruptions_and_source_switch_render_without_errors():
    from streamlit.testing.v1 import AppTest

    app = AppTest.from_file(str(ROOT / "app.py")).run(timeout=180)
    assert not app.exception
    assert [tab.label for tab in app.tabs] == [
        "Activity monitor", "Model comparison", "Robustness lab", "Experiment notes"]
    for name in ("cnn", "lstm", "cnn_lstm", "cnn_lstm_aug"):
        app.sidebar.selectbox[0].select(name).run(timeout=60)
        assert not app.exception
        assert app.metric[0].label == "RECOGNIZED ACTIVITY"
    app.sidebar.selectbox[1].select("noise_0.5").run(timeout=60)
    assert not app.exception
    app.sidebar.radio[0].set_value("Upload sensor CSV").run(timeout=60)
    assert not app.exception
    assert any("Bring your own signal" in element.value for element in app.markdown)

