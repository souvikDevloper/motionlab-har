"""Run with: python -m streamlit run app.py"""
from __future__ import annotations

import json
import time
from pathlib import Path

import streamlit as st

from har.constants import CHANNELS, CONDITIONS, DATASET_PAGE, DEEP_MODELS, LABELS, MODEL_NAMES, ROOT, SAMPLE_RATE

st.set_page_config(page_title="MotionLab · Activity recognition", page_icon="◉", layout="wide")

st.markdown("""<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap');
html, body, [class*="css"], .stMarkdown, .stButton, .stSelectbox {font-family:'DM Sans',sans-serif}
h1,h2,h3,h4{font-family:'Manrope',sans-serif!important;letter-spacing:-.045em!important}
.block-container{max-width:1440px;padding:3.8rem 2.6rem 3rem}
[data-testid="stHeader"]{background:rgba(245,247,250,.92)}
[data-testid="stSidebar"]{background:#142F38}
[data-testid="stSidebar"] .stMarkdown,[data-testid="stSidebar"] label,[data-testid="stSidebar"] p{color:#e9f0f1}
[data-testid="stSidebar"] [data-testid="stCaptionContainer"] p{color:#a6bfc7}
[data-testid="stSidebar"] [data-baseweb="select"] *{color:#182a35}
[data-testid="stSidebar"] .stRadio div[role="radiogroup"] label{color:#fff}
[data-testid="stMetric"]{background:white;border:1px solid #e3e9ed;padding:18px 20px;border-radius:14px;min-height:112px}
[data-testid="stMetricValue"]{font-family:'Manrope',sans-serif;font-size:1.75rem;letter-spacing:-.04em}
[data-testid="stMetricLabel"] p{font-size:12px;color:#647782}
[data-testid="stVerticalBlockBorderWrapper"]>div{border-color:#e3e9ed!important;border-radius:16px!important}
.eyebrow{color:#127a64;font-size:11px;font-weight:700;letter-spacing:.17em;margin:0 0 10px}
.hero h1{font-size:42px;font-weight:800;line-height:1.15;margin:0 0 12px}
.hero p{color:#687d87;font-size:15px;margin:0 0 18px}
.pill{display:inline-block;border:1px solid #d9e5e5;border-radius:20px;padding:5px 11px;color:#3f646a;background:#eef5f3;font-size:11px;letter-spacing:.035em;margin:0 6px 10px 0}
.side-logo{font-family:'Manrope',sans-serif;font-size:26px;font-weight:800;color:#fff;letter-spacing:-1px;padding:5px 0}
.side-mark{display:inline-grid;place-items:center;width:35px;height:35px;border-radius:10px;color:#153b38;background:#80d8b4;margin-right:10px;font-size:24px}
.side-sub{font-size:10px;letter-spacing:.16em;color:#95b3bd;margin:8px 0 35px}
.side-note{border-top:1px solid #36515a;padding-top:20px;margin-top:38px;font-size:12px;color:#a9c1c9;line-height:1.7}
.tiny{font-size:11px;color:#7b8f98;letter-spacing:.07em;text-transform:uppercase}
.callout{background:#edf6f2;border:1px solid #d7eae1;padding:15px 18px;border-radius:12px;font-size:13px;color:#326857;margin:14px 0}
button[data-baseweb="tab"]{font-size:13px;padding-left:5px;padding-right:22px}
.stTabs [data-baseweb="tab-list"]{gap:10px;margin-top:16px;margin-bottom:20px}
div[data-testid="stDataFrame"]{border-radius:12px}
</style>""", unsafe_allow_html=True)

COLORS = ["#16896D", "#457BD3", "#A47AC9"]
MODEL_COLORS = {MODEL_NAMES[key]: color for key, color in zip(DEEP_MODELS, ["#457BD3", "#C58A45", "#9381BD", "#16896D"])}
PLOT_CONFIG = {"displayModeBar": False, "responsive": True}


@st.cache_data
def read_report(path: str, modified: float) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


@st.cache_data
def replay_data(path: str, modified: float) -> dict:
    with np.load(path, allow_pickle=False) as bundle:
        return {key: bundle[key] for key in bundle.files}


@st.cache_resource
def get_predictor(key: str, modified: float) -> Predictor:
    predictor = Predictor.load(ROOT / "artifacts", key)
    predictor.predict(np.broadcast_to(predictor.scaler.mean, (1, 128, 6)).copy())
    return predictor


def style_plot(fig, height: int = 300):
    fig.update_layout(height=height, margin=dict(l=0, r=12, t=12, b=0), paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", font=dict(family="DM Sans, sans-serif", color="#687d87", size=11),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        hoverlabel=dict(bgcolor="white"))
    fig.update_xaxes(showgrid=False, zeroline=False)
    fig.update_yaxes(gridcolor="#edf0f3", zeroline=False)
    return fig


def signal_figure(signals: np.ndarray):
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.12)
    for group in range(2):
        for axis, color in zip(range(3), COLORS):
            fig.add_trace(go.Scatter(x=np.arange(128) / SAMPLE_RATE, y=signals[:, group * 3 + axis],
                name="XYZ"[axis], legendgroup=str(axis), showlegend=group == 0, mode="lines",
                line=dict(color=color, width=1.9), hovertemplate="%{x:.2f}s · %{y:.4f}<extra>%{fullData.name}</extra>"), row=group + 1, col=1)
    fig.update_yaxes(title_text="Acceleration · g", row=1, col=1)
    fig.update_yaxes(title_text="Rotation · rad/s", row=2, col=1)
    fig.update_xaxes(title_text="Time within window · seconds", row=2, col=1)
    return style_plot(fig, 340)


def score_figure(probabilities: np.ndarray):
    ordering = np.argsort(probabilities)
    fig = go.Figure(go.Bar(x=probabilities[ordering] * 100, y=[LABELS[i] for i in ordering], orientation="h",
        marker_color=["#16896D" if i == probabilities.argmax() else "#dce7ea" for i in ordering],
        text=[f"{probabilities[i]:.1%}" for i in ordering], textposition="outside",
        hovertemplate="%{y} · %{x:.2f}%<extra></extra>"))
    fig.update_xaxes(range=[0, 115], showticklabels=False, showgrid=False)
    fig.update_yaxes(showgrid=False)
    return style_plot(fig, 340)


def display_window(raw: np.ndarray, predictor: Predictor, condition: str, truth: int | None, description: str):
    perturbed = corrupt(raw[None], condition, predictor.scaler.scale, predictor.scaler.mean)[0]
    start = time.perf_counter()
    probabilities = predictor.predict(perturbed[None])[0]
    elapsed = (time.perf_counter() - start) * 1000
    predicted = int(probabilities.argmax())
    columns = st.columns([1.4, 1, 1, 1])
    columns[0].metric("RECOGNIZED ACTIVITY", LABELS[predicted])
    columns[1].metric("MODEL SCORE", f"{probabilities[predicted]:.1%}")
    columns[2].metric("SENSOR WINDOW", "2.56 s")
    columns[3].metric("PREDICTION TIME", f"{elapsed:.1f} ms")
    st.caption(description + (f" · Recorded label: {LABELS[truth]} · {'Correct prediction' if truth == predicted else 'Prediction differs from label'}" if truth is not None else " · No ground-truth label available"))
    left, right = st.columns([1.75, 1])
    with left, st.container(border=True):
        st.markdown("#### The motion signal")
        st.caption("Two sensors. Three axes each. One movement signature.")
        st.plotly_chart(signal_figure(perturbed), use_container_width=True, config=PLOT_CONFIG)
    with right, st.container(border=True):
        st.markdown("#### Activity scores")
        st.caption("Uncalibrated softmax scores across six classes.")
        st.plotly_chart(score_figure(probabilities), use_container_width=True, config=PLOT_CONFIG)
    st.caption("Prediction time includes scaling and one model call after model warmup on this computer. It varies with load and differs from the forward-only benchmark.")


report_path = ROOT / "results" / "experiment.json"
with st.sidebar:
    st.markdown('<div class="side-logo"><span class="side-mark">∿</span>MotionLab</div><div class="side-sub">HUMAN ACTIVITY INTELLIGENCE</div>', unsafe_allow_html=True)
    st.markdown("**WORKSPACE**")
    source = st.radio("Signal source", ["Recorded examples", "Upload sensor CSV"])
    st.markdown("---")
    model_key = st.selectbox("Recognition model", list(DEEP_MODELS), index=2, format_func=MODEL_NAMES.get)
    condition = st.selectbox("Sensor condition", list(CONDITIONS), format_func=CONDITIONS.get)
    st.caption("Change the model or sensor conditions to explore how predictions respond.")
    st.markdown('<div class="side-note">● &nbsp; LOCAL INFERENCE<br>50 Hz sampling · 6 sensor channels<br>128 readings per window<br><br>UCI HAR · waist-mounted smartphone<br>Research & demonstration</div>', unsafe_allow_html=True)

st.markdown('<div class="hero"><div class="eyebrow">SENSOR INTELLIGENCE / EXPERIMENT WORKSPACE</div><h1>Every movement has a signature.</h1><p>Explore lightweight activity recognition, from raw sensor windows to real predictions.</p></div>', unsafe_allow_html=True)
st.markdown('<span class="pill">● &nbsp; Six activities</span><span class="pill">Accelerometer + gyroscope</span><span class="pill">Participant-independent evaluation</span>', unsafe_allow_html=True)

if not report_path.exists() or not (ROOT / "artifacts" / f"{model_key}.pt").exists():
    st.info("Train the models to activate this workspace. Open a terminal in this project and run the command below.")
    st.code("python -m har train", language="bash")
    st.stop()

with st.spinner("Loading the recognition workspace…"):
    import numpy as np
    import pandas as pd
    import plotly.express as px
    import plotly.graph_objects as go
    import torch
    from plotly.subplots import make_subplots

    from har.augment import corrupt
    from har.inference import Predictor, make_windows, prediction_frame, read_sensor_csv

    torch.set_num_threads(4)
    report = read_report(str(report_path), report_path.stat().st_mtime)
    predictor = get_predictor(model_key, (ROOT / "artifacts" / f"{model_key}.pt").stat().st_mtime)
monitor, comparison, robustness, notes = st.tabs(["Activity monitor", "Model comparison", "Robustness lab", "Experiment notes"])

with monitor:
    if source == "Recorded examples":
        samples_path = ROOT / "artifacts" / "replay_samples.npz"
        samples = replay_data(str(samples_path), samples_path.stat().st_mtime)
        c1, c2, c3 = st.columns([1, 1.4, 1.1])
        activity = c1.selectbox("Recorded activity", list(range(6)), format_func=lambda index: LABELS[index])
        choices = np.flatnonzero(samples["labels"] == activity)
        example = c2.slider("Example within this activity", 1, len(choices), 1)
        cycle = c3.checkbox("Cycle recorded examples", value=False)
        st.caption("These are independent held-out UCI windows. Cycling examples is a recorded-data demonstration.")

        @st.fragment(run_every=1 if cycle else None)
        def recorded_monitor():
            key = f"cycle_{activity}"
            offset = st.session_state.get(key, 0) if cycle else 0
            selected = int(choices[(example - 1 + offset) % len(choices)])
            display_window(samples["signals"][selected], predictor, condition, int(samples["labels"][selected]),
                f"UCI test window {samples['original_indices'][selected]} · Participant {samples['subjects'][selected]}")
            if cycle:
                st.session_state[key] = offset + 1

        recorded_monitor()
        if st.button("Prepare predictions for all 72 recorded examples"):
            windows = corrupt(samples["signals"], condition, predictor.scaler.scale, predictor.scaler.mean)
            scores = predictor.predict(windows)
            export = pd.DataFrame({"uci_test_window": samples["original_indices"], "subject": samples["subjects"],
                "recorded_activity": [LABELS[i] for i in samples["labels"]],
                "predicted_activity": [LABELS[i] for i in scores.argmax(1)], "model_score": scores.max(1),
                "model": model_key, "condition": condition})
            st.download_button("Download recorded predictions", export.to_csv(index=False), "recorded_predictions.csv", "text/csv")
    else:
        st.markdown("#### Bring your own signal")
        st.write("Upload a CSV sampled at 50 Hz with accelerometer values in **g** (including gravity) and gyroscope values in **rad/s**. Use at least 128 rows. Each full 128-row window advances by 64 readings.")
        st.code(",".join(("timestamp_s", *CHANNELS)), language=None)
        example_path = ROOT / "examples" / "walking_window.csv"
        st.download_button("Download an example CSV", example_path.read_bytes(), "walking_window.csv", "text/csv")
        uploaded = st.file_uploader("Sensor readings", type=["csv"])
        confirmed = st.checkbox("My readings use 50 Hz, accelerometer g (with gravity), and gyroscope rad/s.")
        if uploaded is not None and confirmed:
            try:
                frame = read_sensor_csv(uploaded)
                windows, starts = make_windows(frame[list(CHANNELS)].to_numpy())
                selected = int(st.number_input("Window number", min_value=1, max_value=len(windows), value=1)) - 1
                display_window(windows[selected], predictor, condition, None, f"Uploaded recording · Window {selected + 1} of {len(windows)} · Starts at {starts[selected] / SAMPLE_RATE:.2f}s")
                if st.button("Classify recording"):
                    scores = predictor.predict(corrupt(windows, condition, predictor.scaler.scale, predictor.scaler.mean))
                    export = prediction_frame(scores, starts)
                    export["model"] = model_key
                    export["condition"] = condition
                    st.dataframe(export, use_container_width=True, hide_index=True)
                    st.download_button("Download predictions", export.to_csv(index=False), "predictions.csv", "text/csv")
                st.caption(f"Trailing readings after the last full window: {len(frame) - (int(starts[-1]) + 128)}. Uploaded files stay in the local app session.")
            except (ValueError, pd.errors.ParserError, UnicodeDecodeError) as error:
                st.error(str(error))
        elif uploaded is not None:
            st.info("Confirm the sampling rate and units to run inference.")

with comparison:
    st.markdown("### Seven approaches. One held-out test.")
    st.write("Models were selected using validation participants. The original test participants were reserved for final evaluation.")
    records = [{"Model": details["name"], "Input": details["input_type"], "Accuracy": details["accuracy"],
        "Macro precision": details["precision_macro"], "Macro recall": details["recall_macro"],
        "Macro F1": details["f1_macro"], "Size · KiB": details["size_kib"],
        "Median · ms": details["latency_ms_median"], "p95 · ms": details["latency_ms_p95"],
        "Parameters": details["parameters"]} for details in report["models"].values()]
    table = pd.DataFrame(records)
    st.dataframe(table.style.format({key: "{:.2%}" for key in ["Accuracy", "Macro precision", "Macro recall", "Macro F1"]})
        .format({"Size · KiB": "{:.1f}", "Median · ms": "{:.3f}", "p95 · ms": "{:.3f}"}), use_container_width=True, hide_index=True)
    st.caption("Classical models use UCI's supplied engineered features; deep models use six sensor channels. Forward timing excludes feature extraction and preprocessing. Model size excludes libraries and runtime. Measurements use this CPU, not a phone.")
    left, right = st.columns([1, 1])
    with left, st.container(border=True):
        st.markdown("#### Accuracy meets footprint")
        chart = px.scatter(table, x="Size · KiB", y="Macro F1", color="Input", hover_name="Model", log_x=True,
            color_discrete_sequence=["#457BD3", "#16896D"], size_max=18)
        chart.update_traces(marker_size=13, marker_line=dict(color="white", width=1.5))
        chart.update_yaxes(tickformat=".0%")
        st.plotly_chart(style_plot(chart, 340), use_container_width=True, config=PLOT_CONFIG)
    with right, st.container(border=True):
        st.markdown("#### Where predictions get confused")
        confusion_model = st.selectbox("Confusion matrix model", list(report["models"]), format_func=MODEL_NAMES.get,
            index=list(report["models"]).index(model_key))
        matrix = np.array(report["models"][confusion_model]["confusion_matrix"])
        chart = px.imshow(matrix, x=LABELS, y=LABELS, text_auto=True, color_continuous_scale=["#f0f6f3", "#16896D"],
            labels=dict(x="Predicted activity", y="Recorded activity", color="Windows"), aspect="auto")
        chart.update_layout(coloraxis_showscale=False)
        st.plotly_chart(style_plot(chart, 275), use_container_width=True, config=PLOT_CONFIG)
    selected_details = report["models"][confusion_model]
    per_class = pd.DataFrame({label: selected_details["per_class"][label] for label in LABELS}).T
    with st.expander("Precision, recall and F1 by activity"):
        st.dataframe(per_class.style.format({"precision": "{:.2%}", "recall": "{:.2%}", "f1-score": "{:.2%}", "support": "{:.0f}"}), use_container_width=True)
    st.download_button("Download model comparison", (ROOT / "results" / "comparison.csv").read_bytes(), "comparison.csv", "text/csv")

with robustness:
    st.markdown("### How well does the signal hold up?")
    st.write("The same held-out windows face the same seeded perturbations for every deep model. Each condition is evaluated separately.")
    robust = pd.DataFrame(report["robustness"])
    robust["Model"] = robust["model"].map(MODEL_NAMES)
    robust["Condition"] = robust["condition"].map(CONDITIONS)
    metric = st.radio("Comparison metric", ["Macro F1", "Accuracy"], horizontal=True)
    metric_key = "f1_macro" if metric == "Macro F1" else "accuracy"
    figure = px.line(robust, x="Condition", y=metric_key, color="Model", markers=True,
        color_discrete_map=MODEL_COLORS, labels={metric_key: metric})
    figure.update_yaxes(range=[0, 1.02], tickformat=".0%")
    figure.update_traces(line_width=2.3, marker_size=7)
    st.plotly_chart(style_plot(figure, 380), use_container_width=True, config=PLOT_CONFIG)
    normal = robust[robust["model"] == "cnn_lstm"].set_index("condition")
    augmented = robust[robust["model"] == "cnn_lstm_aug"].set_index("condition")
    c1, c2, c3 = st.columns(3)
    for col, cond in zip((c1, c2, c3), ("clean", "noise_0.5", "rotation_30")):
        delta = float(augmented.loc[cond, metric_key] - normal.loc[cond, metric_key])
        col.metric(CONDITIONS[cond], f"{augmented.loc[cond, metric_key]:.1%}", f"{delta * 100:+.1f} pp vs CNN-LSTM")
    st.caption("Cards show the augmented CNN-LSTM score. Positive differences mean augmentation helped for this run and condition.")
    with st.expander("What each perturbation means", expanded=True):
        st.markdown("**Gaussian noise:** independent noise per reading, with standard deviation 0.1, 0.3 or 0.5 times that channel's clean training standard deviation.\n\n**Orientation:** one random 3D rotation per window, shared by accelerometer and gyroscope. The angle is sampled uniformly within ±15° or ±30°.\n\n**Missing block:** 13 consecutive readings per window (10.16%) replaced by clean training channel means. This simulates missing data after mean imputation.\n\n**Training augmentation:** 50% of windows receive a rotation within ±20° and noise between 0.02σ and 0.30σ; 25% of those also receive a missing block. Validation data stays clean.")
    st.info("These experiments perturb UCI's already preprocessed signals. They do not establish accuracy for a different phone, placement, irregular sampling or live recordings.")
    st.download_button("Download robustness results", (ROOT / "results" / "robustness.csv").read_bytes(), "robustness.csv", "text/csv")

with notes:
    st.markdown("### A reproducible experiment, with visible boundaries.")
    split = report["split"]
    c1, c2, c3 = st.columns(3)
    c1.metric("FIT WINDOWS", f"{split['fit_windows']:,}", f"{len(split['fit_subjects'])} participants", delta_color="off")
    c2.metric("VALIDATION WINDOWS", f"{split['validation_windows']:,}", f"{len(split['validation_subjects'])} participants", delta_color="off")
    c3.metric("TEST WINDOWS", f"{split['test_windows']:,}", f"{len(split['test_subjects'])} participants", delta_color="off")
    st.markdown("#### The protocol")
    st.write("The original UCI participant split is preserved. Five of the 21 official training participants form a validation set; the other 16 fit the models and scalers. Every participant belongs to exactly one set. Overlapping windows from one person stay together.")
    st.write("Classical baselines compare two predefined parameter settings each. Neural networks use validation macro F1 for checkpoint selection, learning-rate adjustment and early stopping. Every model is selected before test predictions are computed.")
    st.write("The CNN-LSTM and augmented CNN-LSTM share the same architecture, initialization seed, optimization settings and fit/validation participants. This is a single-seed comparison; repeated seeds and subject folds are needed for stronger conclusions.")
    st.markdown("#### Training curves")
    histories = pd.DataFrame([{**entry, "Model": MODEL_NAMES[key]} for key, history in report["history"].items() for entry in history])
    figure = px.line(histories, x="epoch", y="validation_f1", color="Model", color_discrete_map=MODEL_COLORS,
        labels={"epoch": "Epoch", "validation_f1": "Validation macro F1"})
    figure.update_yaxes(tickformat=".0%")
    st.plotly_chart(style_plot(figure, 300), use_container_width=True, config=PLOT_CONFIG)
    with st.expander("Configuration, participants and hardware"):
        st.json({"config": report["config"], "split": split, "environment": report["environment"], "dataset": report["dataset"]})
    st.markdown("#### What this implementation demonstrates")
    st.write("Offline activity recognition and simulated robustness testing on six waist-mounted smartphone activities. It includes recorded-data replay and CSV inference. Live phone capture, medical monitoring, calibrated certainty and mobile hardware benchmarks are future work.")
    st.markdown(f"Dataset: Reyes-Ortiz, Anguita, Ghio, Oneto and Parra (2013). [UCI Human Activity Recognition Using Smartphones]({DATASET_PAGE}). DOI: 10.24432/C54S4K. Dataset license: CC BY 4.0.")
    st.download_button("Download full experiment JSON", report_path.read_bytes(), "experiment.json", "application/json")
    st.download_button("Download standalone experiment report", (ROOT / "results" / "report.html").read_bytes(), "motionlab-report.html", "text/html")

st.markdown('<p class="tiny" style="margin-top:35px">MOTIONLAB &nbsp; / &nbsp; RECOGNIZE · COMPARE · UNDERSTAND</p>', unsafe_allow_html=True)

