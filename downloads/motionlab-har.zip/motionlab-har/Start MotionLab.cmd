@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.10 or newer is required. Install Python and select Add Python to PATH.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating the local Python environment...
  python -m venv .venv
  if errorlevel 1 goto failed
)
if not exist ".venv\motionlab-installed" (
  echo Installing MotionLab dependencies. This may take several minutes...
  ".venv\Scripts\python.exe" -m pip install -e ".[dev]"
  if errorlevel 1 goto failed
  type nul > ".venv\motionlab-installed"
)
echo Opening MotionLab. Keep this window open while using the application.
".venv\Scripts\python.exe" -m streamlit run app.py --server.headless false
if errorlevel 1 goto failed
exit /b 0
:failed
echo MotionLab could not start. Review the message above and the README.
pause
exit /b 1

