from __future__ import annotations

import json
import platform
import random
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
import torch
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from torch import nn

from .augment import corrupt, training_augmentation
from .constants import CHANNELS, CONDITIONS, DATASET_PAGE, DEEP_MODELS, LABELS, MODEL_NAMES, SAMPLE_RATE, WINDOW
from .data import SignalScaler, download_dataset, load_split, participant_split
from .metrics import classification_metrics, deep_probabilities, latency_ms
from .models import load_model, make_model


@dataclass
class TrainConfig:
    seed: int = 42
    epochs: int = 24
    batch_size: int = 128
    learning_rate: float = 0.002
    weight_decay: float = 0.0001
    patience: int = 6
    threads: int = 4


def seed_everything(seed: int, threads: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(True)


def fit_deep(name: str, x_fit: np.ndarray, y_fit: np.ndarray, x_val: np.ndarray, y_val: np.ndarray,
             scaler: SignalScaler, config: TrainConfig, model_dir: Path) -> tuple[torch.nn.Module, dict, list[dict]]:
    seed_everything(config.seed, config.threads)
    rng = np.random.default_rng(config.seed)
    model = make_model(name)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)
    loss_fn = nn.CrossEntropyLoss()
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", patience=2, factor=0.5)
    scaled_val = scaler.transform(x_val)
    best_f1, best_epoch, stalled = -1.0, 0, 0
    history = []
    path = model_dir / f"{name}.pt"
    started = time.perf_counter()
    for epoch in range(1, config.epochs + 1):
        model.train()
        order = rng.permutation(len(x_fit))
        total_loss, correct = 0.0, 0
        for start in range(0, len(order), config.batch_size):
            indices = order[start:start + config.batch_size]
            batch = x_fit[indices]
            if name == "cnn_lstm_aug":
                batch = training_augmentation(batch, scaler.scale, scaler.mean, rng)
            inputs = torch.from_numpy(scaler.transform(batch))
            targets = torch.from_numpy(y_fit[indices])
            optimizer.zero_grad(set_to_none=True)
            logits = model(inputs)
            loss = loss_fn(logits, targets)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            total_loss += float(loss.detach()) * len(indices)
            correct += int((logits.argmax(1) == targets).sum())
        val_prob = deep_probabilities(model, scaled_val)
        score = float(f1_score(y_val, val_prob.argmax(1), labels=range(6), average="macro", zero_division=0))
        history.append({"epoch": epoch, "loss": total_loss / len(x_fit), "train_accuracy": correct / len(x_fit),
                        "validation_f1": score, "learning_rate": optimizer.param_groups[0]["lr"]})
        print(f"{name:14s} epoch {epoch:02d}/{config.epochs} loss={total_loss / len(x_fit):.4f} val_macro_f1={score:.4f}", flush=True)
        scheduler.step(score)
        if score > best_f1 + 1e-6:
            best_f1, best_epoch, stalled = score, epoch, 0
            torch.save({"format_version": 1, "model_key": name, "state_dict": model.state_dict(),
                        "channels": list(CHANNELS), "labels": list(LABELS), "window": WINDOW,
                        "sample_rate": SAMPLE_RATE, "seed": config.seed, "best_epoch": epoch}, path)
        else:
            stalled += 1
        if stalled >= config.patience:
            break
    model, _ = load_model(path)
    return model, {"validation_f1": best_f1, "best_epoch": best_epoch,
                   "training_seconds": time.perf_counter() - started, "epochs_run": len(history)}, history


def baseline_candidates(name: str, seed: int):
    if name == "logistic":
        return [(f"C={c}", make_pipeline(StandardScaler(), LogisticRegression(C=c, max_iter=2500, random_state=seed)))
                for c in (0.1, 1.0)]
    if name == "svm":
        return [(f"C={c}, gamma=scale", make_pipeline(StandardScaler(), SVC(C=c, kernel="rbf", gamma="scale")))
                for c in (1.0, 10.0)]
    return [(f"trees=200, max_depth={depth}", RandomForestClassifier(
        n_estimators=200, max_depth=depth, max_features="sqrt", n_jobs=4, random_state=seed))
            for depth in (20, None)]


def fit_baseline(name: str, features, labels, validation_features, validation_labels, seed: int):
    started = time.perf_counter()
    best, best_score, best_parameters, search = None, -1.0, "", []
    for parameters, model in baseline_candidates(name, seed):
        model.fit(features, labels)
        score = float(f1_score(validation_labels, model.predict(validation_features), average="macro", zero_division=0))
        print(f"{name:14s} {parameters} val_macro_f1={score:.4f}", flush=True)
        search.append({"parameters": parameters, "validation_f1": score})
        if score > best_score:
            best, best_score, best_parameters = model, score, parameters
    if name == "random_forest":
        best.set_params(n_jobs=1)  # Stable single-window timing without a thread-pool launch.
    return best, {"validation_f1": best_score, "selected_parameters": best_parameters, "search": search,
                  "training_seconds": time.perf_counter() - started}


def run_training(root: Path, data_dir: Path, config: TrainConfig) -> dict:
    if config.epochs < 1 or config.patience < 1 or config.batch_size < 2 or config.threads < 1:
        raise ValueError("Epochs, patience, threads must be positive; batch size must be at least 2.")
    seed_everything(config.seed, config.threads)
    dataset = download_dataset(data_dir)
    train, test = load_split(dataset, "train"), load_split(dataset, "test")
    if set(train.subjects) & set(test.subjects):
        raise ValueError("Official training and test participants overlap.")
    fit, validation = participant_split(train.subjects, train.labels, config.seed)
    scaler = SignalScaler.fit(train.signals[fit])
    model_dir, results_dir = root / "artifacts", root / "results"
    model_dir.mkdir(parents=True, exist_ok=True)
    results_dir.mkdir(parents=True, exist_ok=True)
    scaler.save(model_dir / "signal_scaler.npz")
    provenance_path = data_dir / "provenance.json"
    provenance = json.loads(provenance_path.read_text(encoding="utf-8")) if provenance_path.exists() else {"source": DATASET_PAGE}
    report = {
        "format_version": 1, "completed_at_utc": None, "config": asdict(config), "dataset": provenance,
        "environment": {"python": platform.python_version(), "torch": torch.__version__, "sklearn": sklearn.__version__,
                        "numpy": np.__version__, "platform": platform.platform(), "processor": platform.processor(),
                        "device": "cpu", "torch_threads": config.threads},
        "split": {
            "fit_subjects": np.unique(train.subjects[fit]).tolist(),
            "validation_subjects": np.unique(train.subjects[validation]).tolist(),
            "test_subjects": np.unique(test.subjects).tolist(),
            "fit_windows": len(fit), "validation_windows": len(validation), "test_windows": len(test.labels),
            "fit_class_counts": np.bincount(train.labels[fit], minlength=6).tolist(),
            "validation_class_counts": np.bincount(train.labels[validation], minlength=6).tolist(),
            "test_class_counts": np.bincount(test.labels, minlength=6).tolist(),
        },
        "protocol": {
            "selection": "Validation macro F1 only; test set used after all model selection is complete.",
            "inputs_deep": "128 × 6: total accelerometer (g) and body gyroscope (rad/s), in XYZ order.",
            "inputs_classical": "561 UCI-provided engineered features; not computed by this implementation.",
            "normalization": "Per-channel training mean and std; classical extra StandardScaler fitted only on fit participants.",
            "latency": "CPU, batch 1, warmup 10, repeats 60; model predict/forward only; excludes preprocessing and 561-feature extraction.",
            "size": "Serialized model file only, excluding shared signal scaler, interpreter and libraries.",
            "robustness": "Deep models only. Same perturbations/seed for every model. Noise σ relative to clean training channel std; rotations shared across both sensors; missing block filled with clean training channel means.",
            "limitations": "One seed and one held-out subject split. Corrupted preprocessed UCI windows are simulations, not real phone validation; softmax scores are uncalibrated. No claim of statistical significance or measured mobile latency.",
        },
        "models": {}, "robustness": [], "history": {},
    }
    # Fit and select every model before accessing test predictions.
    fitted = {}
    for name in ("logistic", "random_forest", "svm"):
        model, details = fit_baseline(name, train.features[fit], train.labels[fit],
                                      train.features[validation], train.labels[validation], config.seed)
        joblib.dump(model, model_dir / f"{name}.joblib", compress=3)
        fitted[name] = (model, details)
    for name in DEEP_MODELS:
        model, details, history = fit_deep(name, train.signals[fit], train.labels[fit],
            train.signals[validation], train.labels[validation], scaler, config, model_dir)
        fitted[name] = (model, details)
        report["history"][name] = history
        # Save recoverable progress during a longer CPU run.
        (results_dir / "training_progress.json").write_text(json.dumps({"completed_models": list(fitted), "history": report["history"]}, indent=2), encoding="utf-8")
    scaled_test = scaler.transform(test.signals)
    for name, (model, details) in fitted.items():
        if name in DEEP_MODELS:
            probabilities = deep_probabilities(model, scaled_test)
            predictions = probabilities.argmax(1)
            sample = torch.from_numpy(scaled_test[:1])
            with torch.inference_mode():
                timing = latency_ms(model, sample)
            size = (model_dir / f"{name}.pt").stat().st_size
            parameters = sum(p.numel() for p in model.parameters())
        else:
            predictions = model.predict(test.features)
            timing = latency_ms(model.predict, test.features[:1])
            size = (model_dir / f"{name}.joblib").stat().st_size
            parameters = None
        report["models"][name] = {
            "name": MODEL_NAMES[name], "input_type": "sensor windows" if name in DEEP_MODELS else "561 engineered features",
            **details, **classification_metrics(test.labels, predictions), **timing,
            "size_kib": size / 1024, "parameters": parameters,
        }
        print(f"TEST {name:14s} accuracy={report['models'][name]['accuracy']:.4f} macro_f1={report['models'][name]['f1_macro']:.4f}", flush=True)
    for condition in CONDITIONS:
        perturbed = scaler.transform(corrupt(test.signals, condition, scaler.scale, scaler.mean, config.seed + 2000))
        for name in DEEP_MODELS:
            predictions = deep_probabilities(fitted[name][0], perturbed).argmax(1)
            metrics = classification_metrics(test.labels, predictions)
            report["robustness"].append({"model": name, "condition": condition,
                "accuracy": metrics["accuracy"], "f1_macro": metrics["f1_macro"]})
        print(f"Robustness evaluated: {condition}", flush=True)
    # A bounded, balanced replay collection; no synthetic signals and no training examples.
    rng = np.random.default_rng(config.seed)
    sample_indices = np.concatenate([rng.choice(np.flatnonzero(test.labels == label), 12, replace=False) for label in range(6)])
    np.savez_compressed(model_dir / "replay_samples.npz", signals=test.signals[sample_indices],
                        labels=test.labels[sample_indices], subjects=test.subjects[sample_indices], original_indices=sample_indices)
    example = pd.DataFrame(test.signals[sample_indices[0]], columns=CHANNELS)
    example.insert(0, "timestamp_s", np.arange(WINDOW) / SAMPLE_RATE)
    (root / "examples").mkdir(exist_ok=True)
    example.to_csv(root / "examples" / "walking_window.csv", index=False)
    report["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
    write_results(report, results_dir)
    (results_dir / "training_progress.json").unlink(missing_ok=True)
    return report


def write_results(report: dict, results_dir: Path) -> None:
    (results_dir / "experiment.json").write_text(json.dumps(report, indent=2, allow_nan=False), encoding="utf-8")
    rows = [{"model_key": key, **{k: v for k, v in value.items() if k not in {"confusion_matrix", "per_class", "search"}}}
            for key, value in report["models"].items()]
    pd.DataFrame(rows).to_csv(results_dir / "comparison.csv", index=False)
    pd.DataFrame(report["robustness"]).to_csv(results_dir / "robustness.csv", index=False)
    make_html_report(report, results_dir / "report.html")


def make_html_report(report: dict, target: Path) -> None:
    import html
    import plotly.express as px
    import plotly.io as pio
    rows = pd.DataFrame([{"Model": value["name"], "Accuracy": value["accuracy"], "Macro F1": value["f1_macro"],
        "Size (KiB)": value["size_kib"], "Median forward (ms)": value["latency_ms_median"]} for value in report["models"].values()])
    robustness = pd.DataFrame(report["robustness"])
    robustness["Model"] = robustness["model"].map(MODEL_NAMES)
    robustness["Condition"] = robustness["condition"].map(CONDITIONS)
    figure = px.line(robustness, x="Condition", y="f1_macro", color="Model", markers=True,
                     labels={"f1_macro": "Macro F1"}, template="plotly_white")
    figure.update_yaxes(range=[0, 1])
    chart = pio.to_html(figure, full_html=False, include_plotlyjs=True)
    table = rows.to_html(index=False, float_format=lambda value: f"{value:.4f}", border=0)
    protocol = "".join(f"<li><b>{html.escape(key.title())}</b>: {html.escape(value)}</li>" for key, value in report["protocol"].items())
    target.write_text(f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MotionLab · experiment report</title><style>body{{font:16px/1.6 system-ui;color:#182a35;background:#f5f7fa;margin:0}}main{{max-width:1100px;margin:48px auto;padding:32px;background:white;border-radius:20px}}h1{{font-size:42px}}table{{width:100%;border-collapse:collapse;font-size:14px}}td,th{{padding:12px;text-align:left;border-bottom:1px solid #e6ecef}}a{{color:#127a64}}li{{margin:12px 0}}</style><main>
<p>MOTIONLAB / MEASURED EXPERIMENT</p><h1>Human activity, recognized.</h1><p>Seven compact classifiers. Six activities. A participant-independent test.</p>
<p>Fit: {report['split']['fit_windows']:,} windows · Validation: {report['split']['validation_windows']:,} · Test: {report['split']['test_windows']:,}. Seed {report['config']['seed']}. Completed {html.escape(report['completed_at_utc'])}.</p>
{table}<h2>Robustness under simulated sensor shifts</h2>{chart}<h2>How to interpret these results</h2><ul>{protocol}</ul>
<p>Dataset: Reyes-Ortiz et al. (2013), <a href="{DATASET_PAGE}">UCI Human Activity Recognition Using Smartphones</a>, DOI 10.24432/C54S4K. CC BY 4.0.</p>
<p>Detailed per-class metrics, confusion matrices, participant IDs, training curves, hardware, configuration and archive fingerprint are in experiment.json.</p></main></html>''', encoding="utf-8")

