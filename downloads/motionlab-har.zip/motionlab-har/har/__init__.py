"""MotionLab: sensor activity recognition with participant-independent evaluation."""

__version__ = "1.0.0"

