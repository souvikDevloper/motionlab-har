from __future__ import annotations

import torch
from torch import nn


class CNN(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv1d(6, 32, 5, padding=2), nn.BatchNorm1d(32), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(32, 64, 5, padding=2), nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(64, 64, 3, padding=1), nn.ReLU(), nn.AdaptiveAvgPool1d(1),
            nn.Flatten(), nn.Dropout(0.2), nn.Linear(64, 6),
        )

    def forward(self, signals: torch.Tensor) -> torch.Tensor:
        return self.network(signals.transpose(1, 2))


class LSTM(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.recurrent = nn.LSTM(6, 48, batch_first=True)
        self.head = nn.Sequential(nn.Dropout(0.2), nn.Linear(48, 6))

    def forward(self, signals: torch.Tensor) -> torch.Tensor:
        sequence, _ = self.recurrent(signals)
        return self.head(sequence.mean(dim=1))


class CNNLSTM(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.convolution = nn.Sequential(
            nn.Conv1d(6, 32, 5, padding=2), nn.BatchNorm1d(32), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(32, 48, 5, padding=2), nn.BatchNorm1d(48), nn.ReLU(), nn.MaxPool1d(2),
        )
        self.recurrent = nn.LSTM(48, 48, batch_first=True)
        self.head = nn.Sequential(nn.Dropout(0.2), nn.Linear(48, 6))

    def forward(self, signals: torch.Tensor) -> torch.Tensor:
        local = self.convolution(signals.transpose(1, 2)).transpose(1, 2)
        sequence, _ = self.recurrent(local)
        return self.head(sequence.mean(dim=1))


def make_model(name: str) -> nn.Module:
    factories = {"cnn": CNN, "lstm": LSTM, "cnn_lstm": CNNLSTM, "cnn_lstm_aug": CNNLSTM}
    if name not in factories:
        raise ValueError(f"Unknown deep model: {name}")
    return factories[name]()


def load_model(path, device: str = "cpu") -> tuple[nn.Module, dict]:
    checkpoint = torch.load(path, map_location=device, weights_only=True)
    if checkpoint.get("format_version") != 1:
        raise ValueError("Unsupported model artifact version.")
    model = make_model(checkpoint["model_key"]).to(device)
    model.load_state_dict(checkpoint["state_dict"])
    model.eval()
    return model, checkpoint

