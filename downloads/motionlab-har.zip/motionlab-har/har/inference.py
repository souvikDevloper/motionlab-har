from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from .constants import CHANNELS, LABELS, SAMPLE_RATE, STRIDE, WINDOW
from .data import SignalScaler
from .metrics import deep_probabilities
from .models import load_model


@dataclass
class Predictor:
    model: torch.nn.Module
    scaler: SignalScaler

    @classmethod
    def load(cls, artifacts: Path, name: str = "cnn_lstm_aug") -> "Predictor":
        model, checkpoint = load_model(artifacts / f"{name}.pt")
        if checkpoint["channels"] != list(CHANNELS) or checkpoint["window"] != WINDOW:
            raise ValueError("Model input schema differs from this application.")
        return cls(model, SignalScaler.load(artifacts / "signal_scaler.npz"))

    def predict(self, windows: np.ndarray) -> np.ndarray:
        windows = np.asarray(windows, dtype=np.float32)
        if windows.ndim != 3 or windows.shape[1:] != (WINDOW, 6) or len(windows) == 0:
            raise ValueError("Expected a nonempty array of shape (windows, 128, 6).")
        if not np.isfinite(windows).all():
            raise ValueError("Sensor data must be finite; impute missing readings first.")
        return deep_probabilities(self.model, self.scaler.transform(windows))


def read_sensor_csv(source) -> pd.DataFrame:
    frame = pd.read_csv(source)
    missing = set(CHANNELS) - set(frame.columns)
    if missing:
        raise ValueError("Missing sensor columns: " + ", ".join(sorted(missing)))
    if len(frame) < WINDOW:
        raise ValueError(f"At least {WINDOW} rows (2.56 seconds at 50 Hz) are required.")
    if len(frame) > 100_000:
        raise ValueError("Please upload at most 100,000 readings at a time.")
    try:
        sensors = frame[list(CHANNELS)].astype(np.float32)
    except (ValueError, TypeError) as error:
        raise ValueError("Every sensor column must contain numeric readings.") from error
    if not np.isfinite(sensors.to_numpy()).all():
        raise ValueError("Sensor readings contain missing or nonfinite values.")
    if "timestamp_s" in frame:
        try:
            times = frame["timestamp_s"].to_numpy(dtype=np.float64)
        except (ValueError, TypeError) as error:
            raise ValueError("timestamp_s must contain numeric seconds.") from error
        if not np.isfinite(times).all() or not np.allclose(np.diff(times), 1 / SAMPLE_RATE, atol=0.002, rtol=0):
            raise ValueError("timestamp_s must increase uniformly by 0.02 seconds (50 Hz); resample irregular recordings first.")
        sensors.insert(0, "timestamp_s", times)
    return sensors


def make_windows(readings: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    readings = np.asarray(readings, dtype=np.float32)
    if readings.ndim != 2 or readings.shape[1] != 6 or not np.isfinite(readings).all():
        raise ValueError("Expected finite readings with six sensor channels.")
    if len(readings) < WINDOW:
        raise ValueError("At least 128 sensor rows are required.")
    starts = np.arange(0, len(readings) - WINDOW + 1, STRIDE)
    return np.stack([readings[start:start + WINDOW] for start in starts]), starts


def prediction_frame(probabilities: np.ndarray, starts: np.ndarray) -> pd.DataFrame:
    predictions = probabilities.argmax(axis=1)
    frame = pd.DataFrame({"window": np.arange(len(starts)), "start_s": starts / SAMPLE_RATE,
                          "end_s": (starts + WINDOW) / SAMPLE_RATE,
                          "activity": [LABELS[index] for index in predictions],
                          "model_score": probabilities.max(axis=1)})
    for index, name in enumerate(LABELS):
        frame["score_" + name.lower().replace(" ", "_")] = probabilities[:, index]
    return frame

