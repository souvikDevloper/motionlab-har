from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LABELS = ("Walking", "Upstairs", "Downstairs", "Sitting", "Standing", "Lying down")
UCI_LABELS = ("WALKING", "WALKING_UPSTAIRS", "WALKING_DOWNSTAIRS", "SITTING", "STANDING", "LAYING")
CHANNELS = ("acc_x", "acc_y", "acc_z", "gyro_x", "gyro_y", "gyro_z")
UCI_CHANNELS = tuple(f"{sensor}_{axis}" for sensor in ("total_acc", "body_gyro") for axis in "xyz")
WINDOW = 128
STRIDE = 64
SAMPLE_RATE = 50
DATASET_URL = "https://archive.ics.uci.edu/static/public/240/human+activity+recognition+using+smartphones.zip"
DATASET_SHA256 = "c00b803081a5c797cd5e4b83700a9810b38d53d9d84e01917e090e1fdbc81031"
DATASET_PAGE = "https://archive.ics.uci.edu/dataset/240/human+activity+recognition+using+smartphones"
DEEP_MODELS = ("cnn", "lstm", "cnn_lstm", "cnn_lstm_aug")
MODEL_NAMES = {
    "logistic": "Logistic regression", "svm": "RBF SVM", "random_forest": "Random forest",
    "cnn": "1D CNN", "lstm": "LSTM", "cnn_lstm": "CNN-LSTM", "cnn_lstm_aug": "CNN-LSTM + augmentation",
}
CONDITIONS = {
    "clean": "Clean", "noise_0.1": "Gaussian noise · 0.1σ", "noise_0.3": "Gaussian noise · 0.3σ",
    "noise_0.5": "Gaussian noise · 0.5σ", "rotation_15": "Orientation · ±15°",
    "rotation_30": "Orientation · ±30°", "missing_10": "Missing block · 10%",
}

