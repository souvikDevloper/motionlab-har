"""Perturb raw sensor units before applying the fixed, clean training scaler."""
from __future__ import annotations

import numpy as np


def rotate(signals: np.ndarray, degrees: float, rng: np.random.Generator) -> np.ndarray:
    """One rigid 3D rotation per window, shared by accelerometer and gyroscope."""
    axes = rng.normal(size=(len(signals), 3))
    axes /= np.maximum(np.linalg.norm(axes, axis=1, keepdims=True), 1e-8)
    angles = np.deg2rad(rng.uniform(-degrees, degrees, len(signals)))
    x, y, z = axes.T
    zeros = np.zeros(len(signals))
    cross = np.stack((zeros, -z, y, z, zeros, -x, -y, x, zeros), axis=1).reshape(-1, 3, 3)
    outer = axes[:, :, None] * axes[:, None, :]
    cosine = np.cos(angles)[:, None, None]
    matrix = cosine * np.eye(3) + (1 - cosine) * outer + np.sin(angles)[:, None, None] * cross
    result = signals.copy()
    for start in (0, 3):
        result[:, :, start:start + 3] = np.einsum("bij,btj->bti", matrix, signals[:, :, start:start + 3])
    return result


def missing_block(signals: np.ndarray, fraction: float, fill: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    result = signals.copy()
    length = max(1, round(signals.shape[1] * fraction))
    starts = rng.integers(0, signals.shape[1] - length + 1, len(signals))
    for i, start in enumerate(starts):
        result[i, start:start + length] = fill
    return result


def corrupt(signals: np.ndarray, condition: str, scale: np.ndarray, mean: np.ndarray,
            seed: int = 2042) -> np.ndarray:
    rng = np.random.default_rng(seed)
    if condition == "clean":
        return signals.copy()
    if condition.startswith("noise_"):
        sigma = float(condition.split("_")[1])
        return (signals + rng.normal(size=signals.shape) * scale * sigma).astype(np.float32)
    if condition.startswith("rotation_"):
        return rotate(signals, float(condition.split("_")[1]), rng)
    if condition == "missing_10":
        return missing_block(signals, 0.1, mean, rng)
    raise ValueError(f"Unknown corruption: {condition}")


def training_augmentation(signals: np.ndarray, scale: np.ndarray, mean: np.ndarray,
                          rng: np.random.Generator) -> np.ndarray:
    result = signals.copy()
    # Preserve half the examples as clean anchors. Perturb the remainder in raw units.
    selected = rng.random(len(signals)) < 0.5
    if selected.any():
        augmented = rotate(result[selected], 20, rng)
        severity = rng.uniform(0.02, 0.30, (len(augmented), 1, 1))
        augmented += (rng.normal(size=augmented.shape) * scale * severity).astype(np.float32)
        dropped = rng.random(len(augmented)) < 0.25
        if dropped.any():
            augmented[dropped] = missing_block(augmented[dropped], 0.1, mean, rng)
        result[selected] = augmented
    return result

