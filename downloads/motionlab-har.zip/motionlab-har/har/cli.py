from __future__ import annotations

import argparse
import json
from pathlib import Path

from .constants import DEEP_MODELS, ROOT


def main() -> None:
    parser = argparse.ArgumentParser(description="MotionLab · smartphone activity recognition")
    commands = parser.add_subparsers(dest="command", required=True)
    download = commands.add_parser("download", help="Download the official UCI HAR archive")
    download.add_argument("--data-dir", type=Path, default=ROOT / "data")
    train = commands.add_parser("train", help="Train/select seven models, then evaluate clean and perturbed held-out data")
    train.add_argument("--data-dir", type=Path, default=ROOT / "data")
    train.add_argument("--output-dir", type=Path, default=ROOT)
    train.add_argument("--epochs", type=int, default=24)
    train.add_argument("--patience", type=int, default=6)
    train.add_argument("--batch-size", type=int, default=128)
    train.add_argument("--threads", type=int, default=4)
    train.add_argument("--seed", type=int, default=42)
    predict = commands.add_parser("predict", help="Classify a 50 Hz sensor CSV with a trained deep model")
    predict.add_argument("csv", type=Path)
    predict.add_argument("--model", choices=DEEP_MODELS, default="cnn_lstm_aug")
    predict.add_argument("--artifacts", type=Path, default=ROOT / "artifacts")
    predict.add_argument("--output", type=Path, default=Path("predictions.csv"))
    args = parser.parse_args()
    if args.command == "download":
        from .data import download_dataset
        print(download_dataset(args.data_dir))
    elif args.command == "train":
        from .train import TrainConfig, run_training
        config = TrainConfig(seed=args.seed, epochs=args.epochs, patience=args.patience,
                             batch_size=args.batch_size, threads=args.threads)
        report = run_training(args.output_dir.resolve(), args.data_dir.resolve(), config)
        print(json.dumps({key: {k: value[k] for k in ("accuracy", "f1_macro", "size_kib")}
                          for key, value in report["models"].items()}, indent=2))
    elif args.command == "predict":
        import torch
        from .constants import CHANNELS
        from .inference import Predictor, make_windows, prediction_frame, read_sensor_csv
        torch.set_num_threads(4)
        frame = read_sensor_csv(args.csv)
        windows, starts = make_windows(frame[list(CHANNELS)].to_numpy())
        probabilities = Predictor.load(args.artifacts, args.model).predict(windows)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        prediction_frame(probabilities, starts).to_csv(args.output, index=False)
        print(f"Saved {len(windows)} predictions to {args.output.resolve()}")

