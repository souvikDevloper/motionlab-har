from __future__ import annotations

import time

import numpy as np
import torch
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support

from .constants import LABELS


def classification_metrics(labels: np.ndarray, predictions: np.ndarray) -> dict:
    precision, recall, f1, _ = precision_recall_fscore_support(
        labels, predictions, labels=range(6), average="macro", zero_division=0)
    return {
        "accuracy": float(accuracy_score(labels, predictions)), "precision_macro": float(precision),
        "recall_macro": float(recall), "f1_macro": float(f1),
        "confusion_matrix": confusion_matrix(labels, predictions, labels=range(6)).tolist(),
        "per_class": classification_report(labels, predictions, labels=range(6), target_names=LABELS,
                                           output_dict=True, zero_division=0),
    }


@torch.inference_mode()
def deep_probabilities(model, signals: np.ndarray, device: str = "cpu", batch_size: int = 256) -> np.ndarray:
    model.eval()
    batches = [torch.softmax(model(torch.from_numpy(signals[i:i + batch_size]).to(device)), dim=1).cpu().numpy()
               for i in range(0, len(signals), batch_size)]
    return np.concatenate(batches)


def latency_ms(predict, sample, warmup: int = 10, repeats: int = 60) -> dict:
    for _ in range(warmup):
        predict(sample)
    timings = []
    for _ in range(repeats):
        start = time.perf_counter_ns()
        predict(sample)
        timings.append((time.perf_counter_ns() - start) / 1e6)
    return {"latency_ms_median": float(np.median(timings)), "latency_ms_p95": float(np.percentile(timings, 95))}

