from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

import numpy as np
from sklearn.model_selection import GroupShuffleSplit

from .constants import DATASET_PAGE, DATASET_SHA256, DATASET_URL, UCI_CHANNELS, WINDOW


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe_extract(archive: Path, target: Path) -> None:
    with zipfile.ZipFile(archive) as bundle:
        if sum(info.file_size for info in bundle.infolist()) > 1_000_000_000:
            raise ValueError("Dataset archive exceeds the 1 GB extraction limit.")
        for info in bundle.infolist():
            member = PurePosixPath(info.filename.replace("\\", "/"))
            if member.is_absolute() or ".." in member.parts or any(":" in p for p in member.parts):
                raise ValueError("Unsafe path in dataset archive.")
            destination = target.joinpath(*member.parts)
            if info.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                with bundle.open(info) as source, destination.open("wb") as output:
                    shutil.copyfileobj(source, output)


def download_dataset(data_dir: Path) -> Path:
    """Download the official archive; handle both direct and nested UCI ZIP layouts."""
    data_dir = data_dir.resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    archive = data_dir / "uci-har.zip"
    destination = data_dir / "UCI HAR Dataset"
    if (destination / "train" / "subject_train.txt").is_file():
        return destination
    if not archive.exists():
        request = urllib.request.Request(DATASET_URL, headers={"User-Agent": "MotionLab-HAR/1.0"})
        partial = archive.with_suffix(".partial")
        try:
            with urllib.request.urlopen(request, timeout=45) as response, partial.open("wb") as handle:
                shutil.copyfileobj(response, handle)
            if not zipfile.is_zipfile(partial):
                raise ValueError("The dataset server did not return a valid ZIP archive.")
            partial.replace(archive)
        finally:
            partial.unlink(missing_ok=True)
    if sha256_file(archive) != DATASET_SHA256:
        raise ValueError("Dataset archive checksum differs from the verified UCI archive. Check the source before using a changed download.")
    with tempfile.TemporaryDirectory(prefix="extract-", dir=data_dir) as temporary:
        staging = Path(temporary)
        _safe_extract(archive, staging)
        matches = list(staging.rglob("subject_train.txt"))
        if not matches:
            nested = list(staging.rglob("*.zip"))
            if len(nested) != 1:
                raise ValueError("Unexpected archive layout: cannot find UCI HAR signals.")
            _safe_extract(nested[0], staging / "inner")
            matches = list((staging / "inner").rglob("subject_train.txt"))
        if len(matches) != 1:
            raise ValueError("Expected one UCI HAR Dataset directory.")
        shutil.move(str(matches[0].parent.parent), str(destination))
    provenance = {"url": DATASET_URL, "source": DATASET_PAGE, "archive_sha256": sha256_file(archive)}
    (data_dir / "provenance.json").write_text(json.dumps(provenance, indent=2), encoding="utf-8")
    return destination


@dataclass
class Split:
    signals: np.ndarray
    features: np.ndarray
    labels: np.ndarray
    subjects: np.ndarray


def load_split(dataset: Path, split: str) -> Split:
    if split not in {"train", "test"}:
        raise ValueError("Split must be 'train' or 'test'.")
    directory = dataset / split
    cache = dataset.parent / f"{split}-six-channels.npz"
    if cache.exists():
        with np.load(cache, allow_pickle=False) as saved:
            return Split(*(saved[key] for key in ("signals", "features", "labels", "subjects")))
    labels = np.loadtxt(directory / f"y_{split}.txt", dtype=np.int64).reshape(-1) - 1
    subjects = np.loadtxt(directory / f"subject_{split}.txt", dtype=np.int64).reshape(-1)
    features = np.loadtxt(directory / f"X_{split}.txt", dtype=np.float32)
    signals = np.stack([
        np.loadtxt(directory / "Inertial Signals" / f"{name}_{split}.txt", dtype=np.float32)
        for name in UCI_CHANNELS
    ], axis=-1)
    if signals.shape != (len(labels), WINDOW, 6) or features.shape != (len(labels), 561):
        raise ValueError("Dataset dimensions differ from the expected UCI HAR schema.")
    if len(subjects) != len(labels) or not np.isfinite(signals).all() or not np.isfinite(features).all():
        raise ValueError("Dataset contains missing/nonfinite values or mismatched rows.")
    if set(np.unique(labels)) != set(range(6)):
        raise ValueError("Dataset labels must cover UCI activities 1 through 6.")
    np.savez_compressed(cache, signals=signals, features=features, labels=labels, subjects=subjects)
    return Split(signals, features, labels, subjects)


def participant_split(subjects: np.ndarray, labels: np.ndarray, seed: int = 42) -> tuple[np.ndarray, np.ndarray]:
    """Split official training participants, never overlapping windows from one person."""
    fit, validation = next(GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=seed).split(labels, labels, subjects))
    if set(subjects[fit]) & set(subjects[validation]):
        raise ValueError("Participant leakage in validation split.")
    if set(np.unique(labels[fit])) != set(range(6)) or set(np.unique(labels[validation])) != set(range(6)):
        raise ValueError("Participant split does not contain all six activities.")
    return fit, validation


@dataclass
class SignalScaler:
    mean: np.ndarray
    scale: np.ndarray

    @classmethod
    def fit(cls, signals: np.ndarray) -> "SignalScaler":
        return cls(signals.mean(axis=(0, 1), dtype=np.float64).astype(np.float32),
                   np.maximum(signals.std(axis=(0, 1), dtype=np.float64), 1e-6).astype(np.float32))

    def transform(self, signals: np.ndarray) -> np.ndarray:
        return ((signals - self.mean) / self.scale).astype(np.float32)

    def save(self, path: Path) -> None:
        np.savez(path, mean=self.mean, scale=self.scale)

    @classmethod
    def load(cls, path: Path) -> "SignalScaler":
        with np.load(path, allow_pickle=False) as saved:
            return cls(saved["mean"], saved["scale"])

