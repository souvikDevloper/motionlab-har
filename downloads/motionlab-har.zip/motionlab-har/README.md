# MotionLab

**Robust Lightweight Deep Learning Framework for Smartphone-Based Human Activity Recognition**

A working research implementation and local Streamlit application. It trains seven classifiers on the official UCI HAR dataset, evaluates held-out participants, measures simulated sensor robustness, and lets you inspect real predictions on recorded or uploaded sensor windows.

## Start the application

Python 3.10 or newer is required. Open a terminal in this folder:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Open the local address shown in the terminal, normally **http://localhost:8501**. The delivered project includes trained checkpoints, results and 72 real recorded examples; downloading the full dataset is unnecessary to use the dashboard. Installation may take time because PyTorch is a large dependency. To use an existing compatible Python environment, run `python -m pip install -e ".[dev]"` followed by `python -m streamlit run app.py`.

On Windows, **Start MotionLab.cmd** performs first-time setup if needed and launches the application. Keep its terminal open while using the app.

The four workspace tabs provide:

- **Activity monitor:** select a model, activity and example; inspect six sensor channels, the predicted activity and six class scores. Apply the same perturbations used in evaluation. Cycle independent recorded examples or upload a sensor CSV.
- **Model comparison:** accuracy, macro precision/recall/F1, per-class metrics, confusion matrices, serialized size, parameter counts and forward timing for all seven models.
- **Robustness lab:** compare Gaussian noise, orientation rotations and missing blocks, including the measured change from CNN-LSTM to augmented CNN-LSTM.
- **Experiment notes:** training curves, exact participant split, configuration, hardware, archive fingerprint and downloadable experiment files.

## Reproduce the experiment

```powershell
python -m har download
python -m har train --epochs 24 --patience 6 --threads 4 --seed 42
python -m pytest -q
```

Training downloads the official archive if necessary (about 60 MB compressed; allow approximately 350 MB for extracted files and caches). All seven models are trained on CPU. The default maximum is 24 epochs per neural network, with early stopping; runtime depends on the machine. To keep a separate experiment, pass `--output-dir path/to/new-run`. To share a downloaded dataset, pass `--data-dir path/to/data` to both commands. Training writes model artifacts and results into the specified output directory. Training again with the same output directory replaces that run's files.

The original 21/9 participant train/test split is preserved. A seeded group split holds out five of the 21 training participants for validation, leaving 16 for model fitting. The split is by **participant**, so the 50%-overlapping windows of a person cannot appear in both fit and validation sets. Test predictions are computed only after model selection is complete. Training statistics come from fit participants only. The models are not refitted on the validation participants.

The package does not optimize on test results or promise a particular accuracy. A single seed and one participant split are an initial experiment, not a statistical significance study.

## Included measured run

The delivered checkpoints were actually trained and evaluated on all **2,947 original test windows** from nine held-out participants. Fitting used 5,551 windows from 16 participants; validation used 1,801 windows from five other participants. The maximum was 24 epochs, with validation-driven early stopping, seed 42, PyTorch 2.8.0 (CPU) and four PyTorch threads.

| Model | Test accuracy | Macro F1 | Serialized size |
|---|---:|---:|---:|
| Logistic regression | 94.60% | 94.58% | 37.7 KiB |
| Random forest | 92.53% | 92.11% | 2,014.6 KiB |
| RBF SVM | 94.91% | 94.77% | 3,867.6 KiB |
| 1D CNN | 85.65% | 85.23% | 101.1 KiB |
| LSTM | 87.04% | 86.92% | 46.1 KiB |
| CNN-LSTM | 91.35% | 91.26% | 117.3 KiB |
| CNN-LSTM + augmentation | 89.04% | 88.99% | 117.4 KiB |

In this run, augmentation reduced clean macro F1 from 91.26% to 88.99%, while improving it under 0.5σ Gaussian noise from 60.97% to 79.48% and under ±30° rotation from 80.22% to 84.97%. The LSTM reached 85.65% macro F1 under 0.5σ noise, so the augmented hybrid was not the strongest model under every condition. The compact CNN-LSTM has 27,990 trainable parameters. These are observed outcomes from the included run, not expected values asserted by the program.

`requirements-tested.txt` records direct dependency versions from the validated environment. `results/experiment.json` records the complete run and hardware metadata. The UCI download is pinned by SHA-256 in `har/constants.py` and checked before extracting a fresh archive.

## Models and inputs

| Model | Input | Selection |
|---|---|---|
| Logistic regression | UCI's 561 engineered features | C in {0.1, 1.0}, validation macro F1 |
| RBF SVM | UCI's 561 engineered features | C in {1, 10}, gamma=scale, validation macro F1 |
| Random forest | UCI's 561 engineered features | 200 trees, max depth 20 or unlimited, validation macro F1 |
| 1D CNN | 128 × 6 sensor window | Best clean validation macro F1 checkpoint |
| LSTM | 128 × 6 sensor window | Best clean validation macro F1 checkpoint |
| CNN-LSTM | 128 × 6 sensor window | Best clean validation macro F1 checkpoint |
| CNN-LSTM + augmentation | 128 × 6 sensor window | Best clean validation macro F1 checkpoint |

The deep models use `total_acc_x/y/z` (acceleration including gravity, in g) and `body_gyro_x/y/z` (rad/s) from UCI's already filtered and windowed inertial signals. They do not use UCI's additional body-acceleration channels. Inputs have 128 samples at 50 Hz, corresponding to 2.56 seconds. Channels are standardized using one mean and standard deviation per channel computed from fit participants. The UCI feature vectors are supplied by the dataset; this implementation does not reimplement UCI's 561-feature extraction. Logistic regression and SVM receive an additional StandardScaler fitted on fit participants.

Architecture details are in `har/models.py`:

- CNN: Conv1D 6→32→64→64, pooling, global average pooling and a six-class head.
- LSTM: one 48-unit LSTM with temporal average pooling and a six-class head.
- CNN-LSTM: Conv1D 6→32→48 with two pooling stages, a 48-unit LSTM, temporal average pooling and a six-class head.
- Augmented CNN-LSTM: the identical CNN-LSTM architecture and initialization seed with training-only augmentation.

Networks use AdamW, cross entropy, gradient clipping, dropout, a validation-driven learning-rate schedule and early stopping. Classical and deep models have different input representations. Their test metrics are useful baselines, but differences cannot be attributed solely to classifier architecture.

## Robustness protocol

Every deep model is evaluated on the same full held-out test set under these independent conditions:

| Condition | Definition |
|---|---|
| Clean | Original UCI signal windows |
| Gaussian 0.1σ, 0.3σ, 0.5σ | Independent noise relative to each clean fit channel's standard deviation |
| Orientation ±15°, ±30° | One random 3D rotation per window, shared across accelerometer and gyroscope |
| Missing block 10% | 13 consecutive rows per window (10.16%) replaced by fit channel means |

Perturbations are applied **before** the fixed clean signal scaler; the scaler is never refitted on noisy test data. The same corruption seed is used for every model. Noise-augmented training preserves 50% clean examples; the remainder receives a rotation within ±20° and Gaussian noise sampled between 0.02σ and 0.30σ. A quarter of those augmented windows also receives a missing block. Validation stays clean. The clean and augmented CNN-LSTM share initial weights and optimizer settings; augmentation changes the subsequent random-number stream and optimization path.

The classical models are evaluated on clean engineered features only. Corrupting those features would not reproduce sensor noise; generating noisy versions of UCI's 561-feature pipeline is outside this implementation.

Simulated robustness is not evidence of reliability on another phone, a pocket placement or live unfiltered readings. The project does not infer falls or health conditions.

## Classify a CSV

Use the example in `examples/walking_window.csv`, or supply these columns in any order:

```csv
timestamp_s,acc_x,acc_y,acc_z,gyro_x,gyro_y,gyro_z
0.00,0.0,0.0,1.0,0.0,0.0,0.0
0.02,0.1,0.0,1.0,0.01,0.0,0.0
```

The two sample rows above illustrate the schema; **at least 128 rows** are required. `timestamp_s` is optional, but if present it must increase by 0.02 seconds within a 0.002-second tolerance. Readings must be finite numeric values at 50 Hz. Acceleration must include gravity and use **g**, not m/s²; divide m/s² readings by 9.80665 before use. Gyroscope values must use **rad/s**; multiply degrees/s by π/180. Irregularly sampled data must be resampled before upload. When timestamps are absent, sampling rate is the caller's responsibility.

```powershell
python -m har predict examples/walking_window.csv --model cnn_lstm_aug --output predictions.csv
```

This classifies complete 128-row windows with a 64-row stride; incomplete trailing readings are excluded. The output contains time intervals, predicted activities and all six softmax scores. **Softmax scores are not calibrated probabilities of correctness.** Batch and single-window operations can differ slightly numerically. Independent uploaded windows receive independent simulated rotations; this is a sensitivity tool, not a continuous phone-orientation simulator.

The dashboard runs locally, does not transmit uploaded sensor files to a backend, and holds them in the Streamlit session. The app can display recorded examples automatically; it does not capture phone sensors in real time. Live capture is an extension and is not implemented.

## Reading the results

- `results/report.html`: standalone interactive report; open directly in a browser. Plotly is embedded, so the report works offline.
- `results/experiment.json`: complete metrics, per-class results, confusion matrices, training curves, settings, subject IDs, hardware and archive SHA-256.
- `results/comparison.csv`: one clean-test row per model.
- `results/robustness.csv`: four deep models × seven sensor conditions.
- `artifacts/*.pt`: PyTorch weight checkpoints; `signal_scaler.npz` contains preprocessing statistics.
- `artifacts/*.joblib`: classical estimators.
- `artifacts/replay_samples.npz`: 12 held-out UCI windows per activity, with labels, participant IDs and original test row indices (zero based).

Macro precision, recall and F1 give equal weight to the six classes. Confusion matrices use recorded labels as rows and predictions as columns. Forward timing uses CPU, batch size one, 10 warmup calls and 60 measured calls; median and p95 are reported. It excludes normalization, window assembly and the classical feature extraction cost. Neural forward calls return logits; classical predict calls return class labels. These measurements are for this computer, not a smartphone or a full application. File sizes exclude shared preprocessing, Python, PyTorch and other runtime dependencies. A small parameter count does not guarantee a small application bundle.

## Project layout

```text
app.py                       Streamlit workspace
har/data.py                  Official download, validation, subject split, scaler
har/models.py                CNN, LSTM and CNN-LSTM architectures
har/augment.py               Sensor perturbations and training augmentation
har/train.py                 Model selection, training, evaluation and reporting
har/inference.py             CSV validation, windowing and saved-model inference
har/metrics.py               Classification metrics and timing
har/cli.py                   Download, train and predict commands
tests/                       Leakage, corruption, parsing and model checks
artifacts/                   Trained models, scaler and real replay examples
results/                     Measured experiment outputs
examples/                    Ready-to-upload UCI sensor example
```

## Data attribution

Reyes-Ortiz, J., Anguita, D., Ghio, A., Oneto, L., & Parra, X. (2013). *Human Activity Recognition Using Smartphones*. UCI Machine Learning Repository. [DOI: 10.24432/C54S4K](https://doi.org/10.24432/C54S4K). [Official dataset page](https://archive.ics.uci.edu/dataset/240/human+activity+recognition+using+smartphones). UCI lists the dataset under CC BY 4.0. The bundled replay samples and CSV are derived from this dataset; retain this attribution when redistributing them. This project is an independent implementation.

